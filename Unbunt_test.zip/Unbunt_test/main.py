import pyautogui
# import pyspeedtest
import time
import shutil
import os
import webbrowser
import pydub
import platform
import speech_recognition as sr
import json
from pydub import AudioSegment
import io
import wave
import speech_recognition as sr






# def check_internet():
#         st = pyspeedtest.SpeedTest()
#         speed = st.ping()

#         if speed < 4:
#                 return(internetspeed = False)
#                 else:
#                         return (internetspeed = True)

# check_internet()

def Load_Url():
    url = 'https://www.google.com/recaptcha/api2/demo'

# # MacOS
#     chrome_path = 'open -a /Applications/Google\ Chrome.app %s'

# # Windows
# # chrome_path = 'C:/Program Files (x86)/Google/Chrome/Application/chrome.exe %s'

# # Linux
    chrome_path = '/usr/bin/google-chrome %s'

    webbrowser.get(chrome_path).open(url)
    time.sleep(9)
    
Load_Url()

def Click_not_robot():
    x, y = pyautogui.locateCenterOnScreen('great.png')
    pyautogui.click(x, y)
    pyautogui.click(x, y)
    time.sleep(5)
    # pyautogui.hotkey('ctrl', 'tab')
Click_not_robot()

def  Click_audio_icon():
    x, y = pyautogui.locateCenterOnScreen('ear.png')
    pyautogui.click(x, y)
    pyautogui.click(x, y)
    time.sleep(5)
    
Click_audio_icon()

def click_audio_download_icon():
    x, y = pyautogui.locateCenterOnScreen('audio_download.png')
    pyautogui.click(x, y)
    time.sleep(2)
click_audio_download_icon()

def download():
    pyautogui.hotkey('ctrl', 's')
    time.sleep(.9)
    pyautogui.hotkey('enter')
    time.sleep(2)
   
download()

def curt_unwanted():
    pyautogui.hotkey('ctrl', 'w')
#     time.sleep(2)
curt_unwanted()


def copy():
    src = '/'.join( os.getcwd().split('/')[:3] ) + '/Downloads' + '/audio.mp3'
    dst = os.getcwd()
    print(dst)
    shutil.copy2(src, dst)
copy()

def mp3_to_wav(audio_file_name):
    if audio_file_name.split('.')[1] == 'mp3':    
        sound = AudioSegment.from_mp3(audio_file_name)
        audio_file_name = audio_file_name.split('.')[0] + '.wav'
        sound.export(audio_file_name, format="wav")
mp3_to_wav('audio.mp3')
        

def trascribe():
        r = sr.Recognizer()
        file = sr.AudioFile("audio.wav")
        with file as source:
                audio = r.record(source)
        try:
                global RECOG
                RECOG = r.recognize_wit(audio, key = "B3RTJWQJRC3LZVWKHOS7PG3MY5RN52MN")
                print("You said: " + RECOG)
        except sr.UnknownValueError:
                print("could not understand audio")
        except sr.RequestError as e:
                print("Could not request results ; {0}".format(e))
trascribe()
        
   
def type_result_text_box():
    x,y = pyautogui.locateCenterOnScreen('text.png')
    pyautogui.moveTo(x,y)
    time.sleep(.5)
    pyautogui.doubleClick(x, y)
    time.sleep(1)
    textt = pyautogui.typewrite(RECOG)
    print(RECOG)
type_result_text_box()

def verify():
    x,y = pyautogui.locateCenterOnScreen('verify1.png')
#     pyautogui.moveTo(x,y)
    pyautogui.doubleClick(x, y)
    time.sleep(2)
    
verify()

# def comfirm_verification():
#         try:
#                 x,y = pyautogui.locateCenterOnScreen('sucessful.png')

#         except:
#                 return (sucessful_bypass = False)
#         else:
#                 return(sucessful_bypass = True)
# comfirm_verification()

def remove_audio():
    DOWNLOAD_LOCATION ='/'.join( os.getcwd().split('/')[:3] ) + '/Downloads'
    os.system('rm ./audio.wav 2>/dev/null')
    os.system('rm ./audio.mp3 2>/dev/null')
    # These files may be left over from previous runs, and should be removed just in case.
    os.system('rm ' + DOWNLOAD_LOCATION + '/audio.mp3')
remove_audio()