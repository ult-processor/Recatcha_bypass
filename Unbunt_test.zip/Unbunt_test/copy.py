import shutil
import os

def copy():
    src = '/'.join( os.getcwd().split('/')[:3] ) + '/Downloads' + '/audio.mp3'
    dst = os.getcwd()
    print(dst)
    shutil.copy2(src, dst)
copy()